const { enableDevMode } = require('../../devMode.js');
enableDevMode();
module.exports = require('../../language/predicates.js');