const { enableDevMode } = require('../../devMode.js');
enableDevMode();
module.exports = require('../../utilities/findSchemaChanges.js');