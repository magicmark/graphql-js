const { enableDevMode } = require('../../devMode.js');
enableDevMode();
module.exports = require('../../jsutils/toError.js');