"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildExecutionPlan = buildExecutionPlan;
const isSameSet_ts_1 = require("../../jsutils/isSameSet.js");
const SetMap_ts_1 = require("../../jsutils/SetMap.js");
function buildExecutionPlan(originalGroupedFieldSet, parentDeferUsages = new Set()) {
    const groupedFieldSet = new Map();
    const newGroupedFieldSets = new SetMap_ts_1.SetMap();
    for (const [responseKey, fieldDetailsList] of originalGroupedFieldSet) {
        const filteredDeferUsageSet = getFilteredDeferUsageSet(fieldDetailsList);
        if ((0, isSameSet_ts_1.isSameSet)(filteredDeferUsageSet, parentDeferUsages)) {
            groupedFieldSet.set(responseKey, fieldDetailsList);
            continue;
        }
        const newGroupedFieldSet = newGroupedFieldSets.getOrInsertComputed(filteredDeferUsageSet, () => new Map());
        newGroupedFieldSet.set(responseKey, fieldDetailsList);
    }
    return {
        groupedFieldSet,
        newGroupedFieldSets,
    };
}
function getFilteredDeferUsageSet(fieldDetailsList) {
    const filteredDeferUsageSet = new Set();
    for (const fieldDetails of fieldDetailsList) {
        const deferUsage = fieldDetails.deferUsage;
        if (deferUsage === undefined) {
            filteredDeferUsageSet.clear();
            return filteredDeferUsageSet;
        }
        filteredDeferUsageSet.add(deferUsage);
    }
    for (const deferUsage of filteredDeferUsageSet) {
        let parentDeferUsage = deferUsage.parentDeferUsage;
        while (parentDeferUsage !== undefined) {
            if (filteredDeferUsageSet.has(parentDeferUsage)) {
                filteredDeferUsageSet.delete(deferUsage);
                break;
            }
            parentDeferUsage = parentDeferUsage.parentDeferUsage;
        }
    }
    return filteredDeferUsageSet;
}
//# sourceMappingURL=buildExecutionPlan.js.map