"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.didYouMean = didYouMean;
const formatList_ts_1 = require("./formatList.js");
const MAX_SUGGESTIONS = 5;
function didYouMean(firstArg, secondArg) {
    const [subMessage, suggestions] = secondArg
        ? [firstArg, secondArg]
        : [undefined, firstArg];
    if (suggestions.length === 0) {
        return '';
    }
    let message = ' Did you mean ';
    if (subMessage != null) {
        message += subMessage + ' ';
    }
    const suggestionList = (0, formatList_ts_1.orList)(suggestions.slice(0, MAX_SUGGESTIONS).map((x) => `"${x}"`));
    return message + suggestionList + '?';
}
//# sourceMappingURL=didYouMean.js.map