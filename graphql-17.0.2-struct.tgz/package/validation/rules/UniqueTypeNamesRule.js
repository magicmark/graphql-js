"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UniqueTypeNamesRule = UniqueTypeNamesRule;
const GraphQLError_ts_1 = require("../../error/GraphQLError.js");
function UniqueTypeNamesRule(context) {
    const knownTypeNames = new Map();
    const schema = context.getSchema();
    return {
        ScalarTypeDefinition: checkTypeName,
        ObjectTypeDefinition: checkTypeName,
        InterfaceTypeDefinition: checkTypeName,
        UnionTypeDefinition: checkTypeName,
        EnumTypeDefinition: checkTypeName,
        StructTypeDefinition: checkTypeName,
        InputObjectTypeDefinition: checkTypeName,
    };
    function checkTypeName(node) {
        const typeName = node.name.value;
        if (schema?.getType(typeName)) {
            context.reportError(new GraphQLError_ts_1.GraphQLError(`Type "${typeName}" already exists in the schema. It cannot also be defined in this type definition.`, { nodes: node.name }));
            return;
        }
        const knownNameNode = knownTypeNames.get(typeName);
        if (knownNameNode != null) {
            context.reportError(new GraphQLError_ts_1.GraphQLError(`There can be only one type named "${typeName}".`, {
                nodes: [knownNameNode, node.name],
            }));
        }
        else {
            knownTypeNames.set(typeName, node.name);
        }
        return false;
    }
}
//# sourceMappingURL=UniqueTypeNamesRule.js.map