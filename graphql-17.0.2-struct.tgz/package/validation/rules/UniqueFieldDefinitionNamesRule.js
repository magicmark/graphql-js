"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UniqueFieldDefinitionNamesRule = UniqueFieldDefinitionNamesRule;
const GraphQLError_ts_1 = require("../../error/GraphQLError.js");
const definition_ts_1 = require("../../type/definition.js");
function UniqueFieldDefinitionNamesRule(context) {
    const schema = context.getSchema();
    const existingTypeMap = schema ? schema.getTypeMap() : Object.create(null);
    const knownFieldNames = new Map();
    return {
        StructTypeDefinition: checkFieldUniqueness,
        StructTypeExtension: checkFieldUniqueness,
        InputObjectTypeDefinition: checkFieldUniqueness,
        InputObjectTypeExtension: checkFieldUniqueness,
        InterfaceTypeDefinition: checkFieldUniqueness,
        InterfaceTypeExtension: checkFieldUniqueness,
        ObjectTypeDefinition: checkFieldUniqueness,
        ObjectTypeExtension: checkFieldUniqueness,
    };
    function checkFieldUniqueness(node) {
        const typeName = node.name.value;
        let fieldNames = knownFieldNames.get(typeName);
        if (fieldNames == null) {
            fieldNames = new Map();
            knownFieldNames.set(typeName, fieldNames);
        }
        const fieldNodes = node.fields ?? [];
        for (const fieldDef of fieldNodes) {
            const fieldName = fieldDef.name.value;
            if (hasField(existingTypeMap[typeName], fieldName)) {
                context.reportError(new GraphQLError_ts_1.GraphQLError(`Field "${typeName}.${fieldName}" already exists in the schema. It cannot also be defined in this type extension.`, { nodes: fieldDef.name }));
                continue;
            }
            const knownFieldName = fieldNames.get(fieldName);
            if (knownFieldName != null) {
                context.reportError(new GraphQLError_ts_1.GraphQLError(`Field "${typeName}.${fieldName}" can only be defined once.`, { nodes: [knownFieldName, fieldDef.name] }));
            }
            else {
                fieldNames.set(fieldName, fieldDef.name);
            }
        }
        return false;
    }
}
function hasField(type, fieldName) {
    if ((0, definition_ts_1.isObjectType)(type) || (0, definition_ts_1.isInterfaceType)(type) || (0, definition_ts_1.isStructObjectType)(type)) {
        return type.getFields()[fieldName] != null;
    }
    return false;
}
//# sourceMappingURL=UniqueFieldDefinitionNamesRule.js.map